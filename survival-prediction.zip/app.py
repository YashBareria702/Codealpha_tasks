from flask import Flask, request, jsonify
import pickle
import numpy as np

with open("model/model.pkl", "rb") as f:
    model = pickle.load(f)

app = Flask(__name__)

@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json()
    features = np.array([[data["Pclass"], data["Sex"], data["Age"], data["SibSp"], data["Parch"], data["Fare"]]])
    prediction = model.predict(features)[0]
    return jsonify({"Survived": bool(prediction)})

if __name__ == "__main__":
    app.run(debug=True)
