# Survival Prediction (Shipwreck) 🚢

This project predicts whether a person would survive a sinking ship using machine learning.

## Features Considered:
- **Socio-economic Status (Pclass)**
- **Gender**
- **Age**
- **Family Onboard (SibSp, Parch)**
- **Ticket Fare**

## How to Run:
1. Install dependencies: `pip install -r requirements.txt`
2. Train the model: `python train_model.py`
3. Start the API: `python app.py`
4. Send a request:
   ```bash
   curl -X POST http://127.0.0.1:5000/predict -H "Content-Type: application/json" -d '{"Pclass":3, "Sex":1, "Age":25, "SibSp":0, "Parch":0, "Fare":10}'
   ```

## Dependencies:
- Python 3.8+
- Flask
- Pandas
- NumPy
- Scikit-Learn

## Dataset:
Uses Titanic dataset (place it inside `data/` as `titanic.csv`).
