# Stock Price Prediction Using LSTM 📈

This project predicts stock prices using **Long Short-Term Memory (LSTM) networks**.

## Features:
- Fetches stock price data from **Yahoo Finance** 📊
- Preprocesses data (scaling, sequence creation)
- Trains an **LSTM model** using TensorFlow/Keras
- **Visualizes** predictions vs actual prices

## How to Run:
1. Install dependencies: `pip install -r requirements.txt`
2. Open Jupyter Notebook: `jupyter notebook`
3. Run `stock_prediction.ipynb`

## Dependencies:
- Python 3.8+
- TensorFlow/Keras
- Pandas
- NumPy
- Matplotlib
- Yahoo Finance API

## Dataset:
Stock data is fetched from **Yahoo Finance** dynamically.
